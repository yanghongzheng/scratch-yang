module.exports = require('./blockly_compressed_horizontal').goog;
