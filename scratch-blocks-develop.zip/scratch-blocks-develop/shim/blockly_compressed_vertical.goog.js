module.exports = require('./blockly_compressed_vertical').goog;
