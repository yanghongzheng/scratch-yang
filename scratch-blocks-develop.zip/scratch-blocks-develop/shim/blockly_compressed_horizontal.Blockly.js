module.exports = require('./blockly_compressed_horizontal').Blockly;
